import sys
sys.path.append("./code_modules/python/hal")
sys.path.append("./code_modules/python/dataprocessing")
