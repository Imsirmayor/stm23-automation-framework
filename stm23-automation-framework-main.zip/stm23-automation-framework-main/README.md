# STM Automation Framework

## Introduction

This is the repository where you will include your measurement data and track your code modules like TestStand sequences and Python code. In the following sections we will give you a short introduction on the way of work for the repo.

## Repository Structure

This repository contains the following files & sub folders:

- **code_modules**: Here you shall put all your self-developed code modules.
- **documentation**: Folder for handwritten & automatically generated documentation of your code modules.
- **lab-reports**: Include your lab/assignment reports here.
- **measurement-data**: Destination for you raw measurement results. Please include only the measurement results that were really used in postprocessing scripts or were used to generate figures in your report.
- **notebooks**: Put your Jupyter notebooks for e.g. measurement data analysis in here.
- **tests**: Folder for unit/module/integration/... tests.

- **.gitignore**: This file contains file-extensions and folders that should be ignored from commits

- **Readme.md** this file

- **requirements.txt**: This file contains package dependencies for python to be installed in virtual environment using `pip install -r requirements`.

---

## Setup Instructions

After cloning the repository, please run the `setup.cmd` to setup a default virtual environment.

### Create a Virtual Environment

To simplify local working environment with Python it is a very good practice to create a virtual development environment. This will contain only the dependencies needed for the project.

To accomplish this in the local working copy perform the following steps:

#### Install "virtualenv" Python package

Using the system-wide "pip" command, install the Python package for creating virtual environments.

- `pip install virtualenv`

#### Create Virtual Environment

To create the virtual environment, execute

- `virtualenv .venv`

#### Activate virtual environment

Type `Get-Command python`

| CommandType|Name|Version|Source|
|--|--|--|--|
|Application|python.exe|3.10.11...|C:\Program Files\Python310\python.exe|

Now execute

- `.venv\scripts\activate`

You should see that the command line prompt slightly changed and now starts with `(.venv) C:\...` . Again executing `Get-Command python`

&rarr; Should deliver a slightly different output:

|CommandType|Name|Version|Source|
|--|--|--|--|
|Application|python.exe|3.10.11...|`C:\_git\stm23-automation-framework\.venv\Scripts\python.exe`|

This means that when executing command `python`, the local python interpreter in `C:\_git\stm23-automation-framework\.venv\Scripts\python.exe` will be used instead of the system wide interpreter located in e.g. `C:\Program Files\Python310\python.exe`.

#### **Install required Packages**
  
Finally, we can install the required packages using `pip`. `pip install pytest pyvisa matplotlib`

#### (Optional) Create a pip freeze
  
  Using a pip freeze, we can back up the state of our virtual environment, e.g. as we want to always have the same package versions installed. (Per default, `pip` tries to install the versions of the wanted packages.) Typing `pip freeze > requirements.txt` will create a new file `requirements.txt` with the installed packages + their versions.

<!-- **Hint:** VS Code has a fabulous out of the box integration of Git. In addition the [GitLens extension for VS Code](https://marketplace.visualstudio.com/items?itemName=eamodio.gitlens) delivers even further functionalities that really eases your life when you deal with source code. This may not be required for this lecture, but it will definitely help you in you future career. -->

## Related Jenkins Instance

- Jenkins (http://185.164.5.77:8080)