import PsuNi, ArbNi, DmmNi, ScopeNi
import PsuTti, DmmKs34450A, ArbKs33500B, ScopeKsDSO3014XT
import Arb, Scope, Dmm, Psu

MODELS = {
            "ARB": Arb.Arb,
            "33500B":ArbKs33500B.ArbKeysight,
            "PXIE-5413":ArbNi.ArbNi,
            "DMM": Dmm.Multimeter,
            "34450A":DmmKs34450A.DmmKs34450A,
            "PXIE-4080":DmmNi.NiDmm,
            "SCOPE":Scope.Scope,
            "DSOX3014T":ScopeKsDSO3014XT.ScopeKsDSO3014XT,
            "PXIE-5110":ScopeNi.ScopeNi,
            "PSU":Psu.PowerSupply,
            "PL303QMD":PsuTti.PsuTti,
            "PXIE-4142":PsuNi.PsuNi,
            "PXI-4110":PsuNi.PsuNi
    }

def init_instrument(resoure:str, model:str):
    if model.upper() in MODELS:
        return MODELS[model.upper()](resoure)
    else:
        raise NotImplementedError(f"The given model: {model} is not supported")


if __name__ =="__main__":
    # Configure Power Supply
    psu = init_instrument("PS","pxi-4110")
    psu.configure("1",10,0.1)
    psu.configure("2",-10,0.1)
    

    # Configure Dmm
    #dmm = init_instrument("DMM02","34450A")
    dmm = init_instrument("DMM","pxie-4080")
    dmm.configure(Dmm.Mode.DCI,0.1,5.5)
    
    # Configure Fgen
    #fgen = init_instrument("FGEN","PXIE-5413")
    fgen = init_instrument("AWG02","33500b")
    chn = '0'
    fgen.set_waveform_type(chn,Arb.ArbWaveform.SINE)
    fgen.set_amplitude(chn,0.5)
    fgen.set_dc_offset(chn,0)
    fgen.set_frequency(chn, 1000)
    
    
    # configure Scope
    #scope = init_instrument("SCOPE","pxie-5110")
    scope = init_instrument("SCOPE02","dsox3014t")
    chn = '0'
    scope.set_channel_state(chn,True)
    scope.set_vertical_range(chn,2)
    scope.set_probe_attenuation(chn,1)
    scope.set_vertical_coupling(chn,Scope.Coupling.DC1M)
    chn = '1'
    scope.set_channel_state(chn,True)
    scope.set_vertical_range(chn,2)
    scope.set_probe_attenuation(chn,1)
    scope.set_vertical_coupling(chn,Scope.Coupling.DC1M)
    scope.configure_horizontal(10e-3, 10e6)
    scope.set_trigger_type('0',Scope.Triggertype.EDGE)
    scope.set_trigger_level(0.0)
    scope.set_trigger_edge(Scope.TriggerEdge.RISING)
    
    
    # Measure
    fgen.setOutputState('0',True)
    psu.set_output_state("1",True)
    psu.set_output_state("2",True)
    scope.set_run_state(Scope.Runstate.SINGLE)

    print(dmm.measure())
    print(psu.get_current("1"))
    #print(scope.fetch_waveform('0'))
    print(scope.fetch_frequency('0'))
    print(scope.fetch_vpp('0'))

    print(scope.fetch_phase('0','1'))
    # Close
    psu.set_output_state("1",False)
    psu.set_output_state("2",False)
    fgen.setOutputState('0',False)
    