"""
@author: Wolfgang R.
Description: base instrument class, to define some functions, which are placeholders
"""

class Instrument:
    _ref = None # Protected Variable
    
    def __init__(self):
        raise NotImplementedError
    
    def reset(self):
        raise NotImplementedError
    
    def close(self):
        raise NotImplementedError
    
    def get_serial_number(self):
        raise NotImplementedError
    
    def get_model(self):
        raise NotImplementedError
    
    def get_vendor(self):
        raise NotImplementedError
    
    def get_firmware(self):
        raise NotImplementedError